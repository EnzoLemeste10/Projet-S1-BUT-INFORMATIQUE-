from comu import *

# Test pour cree_reseau
def test_cree_reseau():
    
    assert cree_reseau([("Alice", "Bob"), ("Alice", "Charlie"), ("Bob", "Charlie"), ("David", "Alice")]) == {
        "Alice": ["Bob", "Charlie", "David"],
        "Bob": ["Alice", "Charlie"],
        "Charlie": ["Alice", "Bob"],
        "David": ["Alice"]
    }

    assert cree_reseau([("Emma", "Liam"), ("Emma", "Olivia"), ("Noah", "Liam"), ("Sophia", "Olivia"), ("Sophia", "Noah")]) == {
        "Emma": ["Liam", "Olivia"],
        "Liam": ["Emma", "Noah"],
        "Olivia": ["Emma", "Sophia"],
        "Noah": ["Liam", "Sophia"],
        "Sophia": ["Olivia", "Noah"]
    }


# Test pour liste_personne
def test_liste_personne():

    # Test 1: Vérification de la liste des personnes
    assert liste_personne({"Alice": ["Bob", "Charlie"], "Bob": ["Alice"], "Charlie": ["Alice"]}) == ["Alice", "Bob", "Charlie"]

    # Test 2: Réseau vide
    assert liste_personne({}) == []

    # Test 3: Réseau avec une seule personne
    assert liste_personne({"Alice": []}) == ["Alice"]


# Test pour sont_ami
def test_sont_ami():
    # Test 1: Alice et Bob sont amis
    assert sont_ami({"Alice": ["Bob", "Charlie"], "Bob": ["Alice"], "Charlie": ["Alice"]},"Alice","Bob" ) == True
    assert sont_ami({"Alice": ["Bob", "Charlie"], "Bob": ["Alice"], "Charlie": ["Alice"]},"Bob","Charlie") == False
    assert sont_ami({"Alice": ["Bob", "Charlie"],"Bob": ["Alice", "David"],"Charlie": ["Alice"],"David": ["Bob"]},"Charlie","Bob") == False
    


# Test pour sont_ami_de
def test_sont_ami_de():
    # Test 1: Alice est amie avec Bob et Charlie
    assert sont_ami_de({"Alice": ["Bob", "Charlie"], "Bob": ["Alice"], "Charlie": ["Alice"]}, "Alice", ["Bob", "Charlie"]) == True
    assert sont_ami_de({"Alice": ["Bob", "Charlie", "David"],"Bob": ["Alice", "David"],"Charlie": ["Alice"],"David": ["Alice", "Bob"]},"Alice",["Bob", "Charlie", "David"]) == True
    assert sont_ami_de({"Alice": ["Bob", "Charlie", "David"],"Bob": ["Alice", "David"],"Charlie": ["Alice"],"David": ["Alice", "Bob"]},"Bob",["Charlie", "David"]) == False

# Test pour est_commu
def test_est_commu():
    reseau = {"Alice": ["Bob", "Charlie"], "Bob": ["Alice", "Charlie"], "Charlie": ["Alice", "Bob"]}

    # Test 1: Groupe complètement ami
    assert est_commu(reseau, ["Alice", "Bob", "Charlie"]) == True
    assert est_commu({"Alice": ["Bob", "Charlie"],"Bob": ["Alice", "Charlie"],"Charlie": ["Alice", "Bob"],"David": ["Eve"],"Eve": ["David"]}, ["Alice", "David"]) == False
    assert est_commu({"Alice": ["Bob", "Charlie"],"Bob": ["Alice", "Charlie"],"Charlie": ["Alice", "Bob"],"David": ["Eve"],"Eve": ["David"]}, ["David"]) == True



# Test pour comu
def test_comu():
    reseau = {"Alice": ["Bob", "Charlie"], "Bob": ["Alice", "Charlie"], "Charlie": ["Alice", "Bob"]}
    assert comu(reseau, ["Alice", "Bob", "Charlie"]) == ["Alice", "Bob", "Charlie"]

    reseau = {"Alice": ["Bob"], "Bob": ["Alice", "Charlie"], "Charlie": ["Bob"]}
    assert comu(reseau, ["Alice", "Bob", "Charlie"]) == ["Alice", "Bob"]

#Test pour tri_popu
def test_tri_popu():
    reseau = {"Alice": ["Bob", "Charlie", "David"],"Bob": ["Alice", "Charlie"],"Charlie": ["Alice", "Bob"],"David": ["Alice"]}
    groupe = ["Alice", "Bob", "Charlie", "David"]

    assert tri_popu(reseau, groupe) == ["Alice", "Bob", "Charlie", "David"]
    assert tri_popu(reseau, ["David", "Alice"]) == ["Alice", "David"]

#Test pour comu_dans_reseau
def test_comu_dans_reseau():
    
    reseau = {"Alice": ["Bob", "Charlie"],"Bob": ["Alice", "Charlie"],"Charlie": ["Alice", "Bob"],"David": ["Eve"],"Eve": ["David"]}

    # Test 1 : La plus grande communauté connectée
    assert comu_dans_reseau(reseau) == ["Alice", "Bob", "Charlie"]

    # Test 2 : Réseau avec une seule personne
    assert comu_dans_reseau({"Alice": []}) == ["Alice"]

#Test pour comu_dans_amis
def test_comu_dans_amis():
    reseau = {
        "Alice": ["Bob", "Charlie"],
        "Bob": ["Alice", "Charlie"],
        "Charlie": ["Alice", "Bob"],
        "David": ["Eve"],
        "Eve": ["David"]
    }
    # Test 1 : Communauté des amis d'Alice
    assert comu_dans_amis(reseau, "Alice") == ["Alice", "Bob", "Charlie"]

    # Test 2 : Communauté des amis de David
    assert comu_dans_amis(reseau, "David") == ["David", "Eve"]

#Test pour test_comu_max
def test_comu_max():
    reseau = {
        "Alice": ["Bob", "Charlie"],
        "Bob": ["Alice", "Charlie"],
        "Charlie": ["Alice", "Bob"],
        "David": ["Eve"],
        "Eve": ["David"]
    }
    # Test 1 : La plus grande communauté
    assert comu_max(reseau) == ['Eve', 'David']


test_cree_reseau()
test_liste_personne()
test_sont_ami()
test_sont_ami_de()
test_est_commu()
test_comu()
test_tri_popu()
test_comu_dans_reseau()
test_comu_dans_amis()
test_comu_max()