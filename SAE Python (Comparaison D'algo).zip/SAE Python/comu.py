#1. Fonction cree_reseau, qui prend en paramètre un tableau(tab) de couple et qui renvoie un dictionnaire(dico) reseau 
def cree_reseau(couples):
    # Dictionnaire pour stocker le réseau d'amis
    reseau = {}
    
    # Parcourir chaque couple (a, b)
    for a, b in couples:
        # Si 'a' n'est pas encore dans le réseau, on l'ajoute avec une liste vide
        if a not in reseau:
            reseau[a] = []
        # Si 'b' n'est pas encore dans le réseau, on l'ajoute avec une liste vide
        if b not in reseau:
            reseau[b] = []
        
        # Ajouter 'b' dans la liste des amis de 'a'
        reseau[a].append(b)
        # Ajouter 'a' dans la liste des amis de 'b'
        reseau[b].append(a)
    
    return reseau

#3 Fonction liste_personne qui prend en paramètre un reseau(dico) d'ami et qui renvoie la liste(tab) des personnes présente dans ce réseau
def liste_personne(reseau):
    #Renvoie la liste des clés du réseau
    return(list(reseau))

#4 Fonction sont_ami qui prend en paramètre un reseau(dico),un ami1(str) et un ami2(str) qui renvoie Vrai ou Faux(bool)
def sont_ami(reseau,ami1,ami2):
    #Si l'ami 1 est dans le reseau de l'ami 2 et vice-versa, alors on renvoie Vrai, sinon Faux
    if ami1 in reseau[ami2] and ami2 in reseau[ami1]:
        return True 
    else:
        return False 

#5 Fonction sont_ami_de qui prend en paramètre un reseau(dico), un ami(str) et un groupe(tab) qui renvoie Vrai ou Faux(bool)
def sont_ami_de(reseau,ami,groupe):
    #Initialisation du compteur à 0
    cpt=0
    #Parcours du groupe d'ami
    for i in range(0,len(groupe)):
        #si la fonction sont_ami est vrai,le compteur augmente de 1
        if sont_ami(reseau,ami,groupe[i])==True:
            cpt=cpt+1
    #Si le compteur correspond a la taille du groupe on renvoie Vrai sinon Faux
    if cpt==len(groupe):
        return True
    else:
        return False 

#6 Fonction est_commu qui prend en paramètre un reseau(dico) et un groupe(tab) qui renvoie Vrai ou Faux(bool)
def est_commu(reseau, groupe):
    # Parcourir chaque paire de personnes dans le groupe
    for i in range(len(groupe)):
        for j in range(i + 1, len(groupe)):
            # Si les deux personnes ne sont pas amies, le groupe n'est pas comu
            if not sont_ami(reseau, groupe[i], groupe[j]):
                return False
    return True

#7 Fonction comu qui prend en paramètre un reseau(dico) et un groupe(tab) qui renvoie une communauté(tab)
def comu(reseau, groupe):
    # Initialisation d'une communauté vide
    communaute = []
    
    # On parcourt chaque personne du groupe
    for personne in groupe:
        compatible = True  # Flag pour savoir si la personne est compatible avec la communauté actuelle
        
        # Vérifier si la personne est amie avec tous les membres déjà dans la communauté
        for membre in communaute:
            if not sont_ami(reseau, personne, membre):
                compatible = False
                break
        
        # Si compatible, ajouter la personne à la communauté
        if compatible:
            communaute.append(personne)
    
    return communaute

#8
def tri_popu(reseau, groupe):
    n = len(groupe)
    # Tri à bulles basé sur le nombre d'amis
    for k in range(0, n):
        for j in range(0, n-k-1):
            # Comparer la taille des listes d'amis (nombre d'amis)
            if len(reseau[groupe[j]]) < len(reseau[groupe[j+1]]):
                # Si la personne à gauche a moins d'amis, on échange
                groupe[j], groupe[j+1] = groupe[j+1], groupe[j]
    return groupe

#9
def comu_dans_reseau(reseau):
    # On commence par créer une liste de tous les membres du réseau
    groupe = list(reseau.keys())
    
    # Trie les membres du groupe par popularité décroissante
    groupe_trie = tri_popu(reseau, groupe)
    
    # Liste vide pour la communauté
    communaute = []
    
    # Construction de la communauté
    for personne in groupe_trie:
        compatible = True 
        
        # Vérifier si cette personne est amie avec tous les membres déjà dans la communauté
        for membre in communaute:
            if not sont_ami(reseau, personne, membre):
                compatible = False
                break
        
        # Si compatible, on ajoute la personne à la communauté
        if compatible:
            communaute.append(personne)
    
    return communaute

#10 Fonction comu_dans_amis qui prend en paramètre un reseau(dico) et une personne_debut(str) et qui renvoie une communauté(tab)
def comu_dans_amis(reseau, personne_debut):
    # On commence la communauté avec la personne donnée
    communaute = [personne_debut]
    
    # Récupère les amis de la personne de départ
    amis = reseau[personne_debut]
    
    # Trie les amis de la personne par popularité décroissante
    amis_trie = tri_popu(reseau, amis)
    
    # On examine les amis dans l'ordre de popularité
    for ami in amis_trie:
        compatible = True  # Flag pour savoir si la personne peut être ajoutée
        
        # Vérifier si cette personne est amie avec tous les membres déjà dans la communauté
        for membre in communaute:
            if not sont_ami(reseau, ami, membre):
                compatible = False
                break
        
        # Si compatible, on ajoute l'ami à la communauté
        if compatible:
            communaute.append(ami)
    
    return communaute

#12 Fonction comu_max qui prend en paramètre  un reseau(dico) et qui renvoie max, la plus grande commnanuté(tab)
def comu_max(reseau):
    tab=[]
    personnes=list(reseau.keys())
    for i in range(0,len(personnes)):
        tab.append(comu_dans_amis(reseau,personnes[i]))
    max=tab[0]
    for j in range(1,len(tab)):
        if max<tab[j]:
            max=tab[j]
    return max 

#fonction dico_reseau de l'ancienne SAE

def dico_reseau(amis):
    #creation d'un dictionnaire dico
    dico= {}
    #boucle while, creation des variable prenom et ami 
    i=0
    while i < len(amis):
        prenom = amis[i]
        ami= amis[i+1]
    #condition si prenom n'est pas dans le dictionnaire, on creer une clef prenom ayant comme valeur un tableau vide    
        if prenom not in dico:
            dico[prenom] = []
   #condition si ami n'est pas dans le dictionnaire, on creer une clef prenom ayant comme valeur un tableau vide     
        if ami not in dico:
            dico[ami] = []
    #on ajoute alors aux valeurs l'ami ou le prenom  
        dico[prenom].append(ami)
        dico[ami].append(prenom)
        i = i+2
    #on retourn le dictionnaire dont les clef sont les prénoms des membres du réseau et les valeurs le tableau de leurs amis.
    return dico